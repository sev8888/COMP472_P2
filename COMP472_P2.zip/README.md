# COMP472_P2
github repo URL: https://github.com/sev8888/COMP472_P2
COMP472 mini project 2 
#Sevag Kaspar - 40100393
#Duc Minh Bui - 40073498
#Minh-Tam Do  - 40095639

1) To run the code, extract all files 
2) Have a python IDE installed
3) Run the code
4) A folder called "game_files" which will contain all game traces and generated scoreboard files 
